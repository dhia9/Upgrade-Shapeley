# -*- coding: utf-8 -*-
import csv
import timeit
 
"""
Created on Wed Nov  1 13:22:13 2023

@author: veroe

### Q1.3 Algorithme de PRIM 
def creer_arret_non_uti(dico_adjacences):
    l=[]
    for sommet,adjac in dico_adjacences.items():
        for voisin,cout in adjac.items():
            arret=(sommet,voisin,cout)
            sym_arret=(voisin,sommet,cout)
            if arret not in l and sym_arret not in l:
                l.append(arret)
                
    return l
def arret_cout_min(list_arret,sommet_rejoin):
    #arret_min=list_arret[0]
    i=0
    while i<len(list_arret) and not((list_arret[i][0] in sommet_rejoin and list_arret[i][1] not in sommet_rejoin )or (list_arret[i][1] in sommet_rejoin and list_arret[i][0] not in sommet_rejoin)):
        i+=1
    arret_min=list_arret[i]
    for arret in list_arret:
        if arret[2]<arret_min[2] and( (arret[0] in sommet_rejoin and arret[1] not in sommet_rejoin) or(arret[1] in sommet_rejoin and arret[0] not in sommet_rejoin) ) :
            arret_min=arret
    return arret
    
def prim_couverture_mini(dico_adjacences):

    graph init dict sommet arret
    
    ensemble des sommet util dict (R) dict sommet_rejoin
    ensemble des arrets non encore util (epsi) dict arret_nonutil 
    ensemble arret retenu (CMG) list de tuple
 


    CMG=dict()
    # code à compléter ici...
    sommet_rejoin=[0]
    arret_non_util =creer_arret_non_uti(dico_adjacences)
    print(arret_non_util)
    while len(sommet_rejoin)!=len(dico_adjacences):
        arret=arret_cout_min(arret_non_util,sommet_rejoin)
        print(arret)
        c=input()
        sommet=arret[0]
        if sommet in sommet_rejoin:
            sommet=arret[1]
        sommet_rejoin.append(sommet)
        val=CMG.get(arret[0])
        if val==None:
            CMG[arret[0]]={arret[1]:arret[2]}
        else:
            CMG[arret[0]][arret[1]]=arret[2]
        val=CMG.get(arret[1])
        if val==None:
            CMG[arret[1]]={arret[0]:arret[2]}
        else:
            CMG[arret[1]][arret[0]]=arret[2]
        arret_non_util.remove(arret)
    
    return CMG
            
 """   
def prim_couverture_mini(dico_adjacences):
    R=list(dico_adjacences.keys())[0] 
    epsi=dico_adjacences.copy()
    while len(R)!=len(dico_adjacences):
        
    
####Q2.4 Algorithme de PRIM avec proposition d'amélioration avec utilisation d'un dictionnaire pour les sommets_pris_en_compte

def prim_couverture_mini2(dico_adjacences):
    triplets_retenus = [] 
    # code à reprendre de la question 1.3 et à compléter ici...
    return triplets_retenus


#######Q 2.2 (sur la partie des grands graphes / graphes de taille et de densité variable)



def csvToDic(fic):   
    adjacents = {} # Dictionnaire contenant comme clefs les sommets et
                # comme valeurs la liste des sommets pouvant etre rejoints
                # depuis le sommet designe par la clef.
                # Seuls les arcs non nuls sont retenus ici.             
    with open(fic) as f:
        myReader = csv.reader(f)
        sommet = 0
        for row in myReader:
            '''
             #
             # a completer pour obtenir la représentation du même graphe sous forme d'une matrice d'adjacence
             # '''
    return adjacents
       

##########################################################################################
##########################################################################################

# Q1.1 Exemple d'utilisation

# compléter le dictionnaire des lotissements

dico_lotissements ={0:{1:30,4:20,6:20,5:50,2:40,3:50}
                    ,1:{4:50,2:30,0:30}
                    ,2:{1:30,4:50,3:20,0:40}
                    ,3:{4:40,2:20,0:50}
                    ,4:{0:20,1:50,6:30,5:40,2:50,3:40}
                    ,5:{4:40,0:50}
                    ,6:{4:30,0:20}
                    }

MST_prim_fibre = prim_couverture_mini(dico_lotissements)
print(MST_prim_fibre)
"""
print(f"prim : {MST_prim_fibre}")

fich_cablage = "./grand_graphe.csv" 
adjacents = csvToDic(fich_cablage)


#### Appels pour mesurer le temps d'exécution de Prim

## Q.2.1 Calcul du temps pour la CMG des lotissement câblés
#....integrer la mesure de temps
#prim_couverture_mini(dico_lotissements)
#....
 
#print(f"Temps d'exécution de Prim sur graphe fibré : {prim_time_lotissement} secondes")



## Q.2.3 Calcul du temps pour un grand graphe
#...integrer la mesure de temps
#prim_couverture_mini(adjacents)
#...
 
#print(f"Temps d'exécution de Prim sur grand graphe : {prim_time_grandGraphe} secondes")


"""